from typing import Dict, Any
import cv2
import numpy as np

class VisionTools:
    """Simula CNN/Visión para QR. Reemplazar por Azure ML endpoint o tu modelo local."""
    def read_qr(self, image_path: str) -> Dict[str, Any]:
        img = cv2.imread(image_path)
        if img is None:
            return {"ok": False, "reason": "image_not_found"}
        detector = cv2.QRCodeDetector()
        data, points, _ = detector.detectAndDecode(img)
        if data:
            return {"ok": True, "qr_data": data, "confidence": 0.98}
        return {"ok": False, "reason": "qr_not_detected"}

    def classify_qr(self, qr_data: str) -> Dict[str, Any]:
        if len(qr_data) > 0:
            return {"valid": True, "class": "QR_VALID", "score": 0.984}
        return {"valid": False, "class": "QR_INVALID", "score": 0.0}
