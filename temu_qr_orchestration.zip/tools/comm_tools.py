import os, smtplib
from email.mime.text import MIMEText

class CommTools:
    def send_email(self, subject: str, body: str, to_addr: str = None) -> bool:
        host = os.getenv("SMTP_HOST"); port = int(os.getenv("SMTP_PORT", "587"))
        user = os.getenv("SMTP_USER"); password = os.getenv("SMTP_PASS")
        from_addr = os.getenv("ALERT_EMAIL_FROM", user)
        to_addr = to_addr or os.getenv("ALERT_EMAIL_TO")

        msg = MIMEText(body, "plain", "utf-8")
        msg["Subject"] = subject
        msg["From"] = from_addr
        msg["To"] = to_addr

        with smtplib.SMTP(host, port) as server:
            server.starttls()
            server.login(user, password)
            server.send_message(msg)
        print(f"[EMAIL] Enviado a {to_addr}: {subject}")
        return True
