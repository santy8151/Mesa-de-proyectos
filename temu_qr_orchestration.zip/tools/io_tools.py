from dataclasses import dataclass
from typing import Dict, Any
import os

@dataclass
class IoEvent:
    product_id: str
    image_path: str
    metadata: Dict[str, Any]

class IoTools:
    """Simula publicación/recepción de eventos IoT. Reemplazar por Azure IoT Hub."""
    def publish_event(self, event: IoEvent) -> bool:
        print(f"[IoT] Publicado evento: {event.product_id} -> {event.image_path} | {event.metadata}")
        return True

    def get_next_scan(self) -> IoEvent:
        demo_img = os.path.join("data", "samples", "qr_demo.png")
        return IoEvent(product_id="A2025", image_path=demo_img, metadata={"station": "LINEA-1"})
