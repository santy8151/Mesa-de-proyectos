import os

class InventoryTools:
    """Inventario en memoria. Reemplazar por ERP/MES/DB."""
    def __init__(self):
        self.stock = {"A2025": 12, "B1001": 50, "C9900": 3}
        self.threshold = int(os.getenv("STOCK_MIN_THRESHOLD", "10"))

    def update_scan(self, product_id: str) -> int:
        if product_id not in self.stock:
            self.stock[product_id] = 0
        self.stock[product_id] = max(0, self.stock[product_id] - 1)  # picking demo
        return self.stock[product_id]

    def get_level(self, product_id: str) -> int:
        return self.stock.get(product_id, 0)

    def needs_restock(self, product_id: str) -> bool:
        return self.get_level(product_id) <= self.threshold
