import os
from dotenv import load_dotenv
from crewai import Agent, Task, Crew, Process
from tools.io_tools import IoTools, IoEvent
from tools.vision_tools import VisionTools
from tools.inventory_tools import InventoryTools
from tools.comm_tools import CommTools

load_dotenv()

io = IoTools()
vision = VisionTools()
inventory = InventoryTools()
comm = CommTools()

qr_reader_agent = Agent(
    role="QRReaderAgent",
    goal="Capturar lecturas QR desde líneas de producción y publicarlas como eventos IoT.",
    backstory=("Operario digital de captura. Interactúa con el lector/cámara IR y "
               "genera eventos confiables para el pipeline de inferencia."),
    verbose=True,
)

inference_agent = Agent(
    role="InferenceAgent",
    goal="Validar y clasificar los códigos QR usando CNN/Visión por Computador.",
    backstory=("Especialista de IA. Limpia la señal, valida QR, corrige rotaciones y "
               "devuelve la confianza de lectura."),
    verbose=True,
)

inventory_agent = Agent(
    role="InventoryAgent",
    goal="Actualizar niveles de inventario por producto y decidir reposiciones.",
    backstory=("Planificador de materiales. Sincroniza stock y detecta umbrales mínimos."),
    verbose=True,
)

comm_agent = Agent(
    role="CommAgent",
    goal="Notificar automáticamente a proveedores cuando el stock esté bajo.",
    backstory=("Gestor de comunicaciones. Envía correos formales con datos del lote y consumo estimado."),
    verbose=True,
)

analytics_agent = Agent(
    role="AnalyticsAgent",
    goal="Registrar eventos clave para KPIs y alimentar el dashboard.",
    backstory=("Analista de datos. Registra lectura, inferencia, nivel de stock y acciones tomadas."),
    verbose=True,
)

def task_capture_scan_cb(inputs):
    event = io.get_next_scan()
    io.publish_event(event)
    return {"product_id": event.product_id, "image_path": event.image_path, "meta": event.metadata}

task_capture_scan = Task(
    description="Capturar una lectura QR desde la línea de producción y publicar evento IoT.",
    expected_output="Diccionario con product_id, image_path, meta.",
    agent=qr_reader_agent,
    callback=task_capture_scan_cb,
)

def task_infer_qr_cb(inputs):
    img = inputs["image_path"]
    read = vision.read_qr(img)
    if not read.get("ok"):
        return {"status": "fail", "reason": read.get("reason")}
    cls = vision.classify_qr(read["qr_data"])
    return {
        "status": "ok",
        "qr_data": read["qr_data"],
        "confidence": read["confidence"],
        "class": cls["class"],
        "score": cls["score"],
        "product_id": inputs["product_id"],
        "meta": inputs["meta"],
    }

task_infer_qr = Task(
    description="Validar el QR con CNN/Visión y clasificar su validez.",
    expected_output="Diccionario con qr_data, confidence, class, score.",
    agent=inference_agent,
    context=[task_capture_scan],
    callback=task_infer_qr_cb,
)

def task_update_inventory_cb(inputs):
    if inputs.get("status") != "ok":
        return {"status": "skip", "reason": "no_qr"}
    pid = inputs["product_id"]
    level = inventory.update_scan(pid)
    need = inventory.needs_restock(pid)
    return {"product_id": pid, "level": level, "needs_restock": need, "qr_data": inputs["qr_data"]}

task_update_inventory = Task(
    description="Actualizar nivel de inventario del producto y decidir si requiere reposición.",
    expected_output="Diccionario con product_id, level, needs_restock.",
    agent=inventory_agent,
    context=[task_infer_qr],
    callback=task_update_inventory_cb,
)

def task_notify_cb(inputs):
    if inputs.get("needs_restock"):
        pid = inputs["product_id"]; level = inputs["level"]
        subject = f"[Reposición automática] Producto {pid} por debajo del umbral"
        body = (f"Estimado proveedor,\n\nEl producto {pid} alcanzó un nivel de stock de {level} unidades. "
                f"Solicitamos reposición inmediata según acuerdo.\n\nAtte,\nSistema de Orquestación QR-IoT")
        comm.send_email(subject, body)
        return {"notified": True, "product_id": pid, "level": level}
    return {"notified": False, "product_id": inputs["product_id"], "level": inputs["level"]}

task_notify = Task(
    description="Enviar correo a proveedor cuando el stock esté bajo.",
    expected_output="Diccionario con notified: bool, product_id, level.",
    agent=comm_agent,
    context=[task_update_inventory],
    callback=task_notify_cb,
)

def task_log_cb(inputs):
    print("[KPI] Registro:", inputs)
    return {"logged": True}

task_log = Task(
    description="Registrar evento/acción para KPIs del dashboard.",
    expected_output="logged: True",
    agent=analytics_agent,
    context=[task_notify],
    callback=task_log_cb,
)

def main():
    crew = Crew(
        agents=[qr_reader_agent, inference_agent, inventory_agent, comm_agent, analytics_agent],
        tasks=[task_capture_scan, task_infer_qr, task_update_inventory, task_notify, task_log],
        process=Process.sequential,
        verbose=True,
    )
    result = crew.kickoff()
    print("\\n=== Fin del pipeline ===\\n", result)

if __name__ == "__main__":
    main()
