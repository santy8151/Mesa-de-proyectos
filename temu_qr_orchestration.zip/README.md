# Temu QR Orchestration (CrewAI demo)

Pipeline de agentes para lectura QR -> inferencia CNN -> inventario -> alerta por correo -> logging para KPIs.

## Requisitos
```bash
python -m venv venv && source venv/bin/activate
pip install crewai==0.51.1 pydantic==2.8.2 python-dotenv==1.0.1 pillow==10.4.0 opencv-python==4.10.0.84 numpy==1.26.4
```

## Configuración
Crea un archivo `.env` en el raíz con:
```
SMTP_HOST=smtp.tu-proveedor.com
SMTP_PORT=587
SMTP_USER=tu_usuario
SMTP_PASS=tu_password
ALERT_EMAIL_TO=proveedor@dominio.com
ALERT_EMAIL_FROM=operaciones@tuempresa.com
STOCK_MIN_THRESHOLD=10
```
Opcional (Azure):
```
AZURE_IOT_HUB_CONNSTR=...
AZURE_ML_ENDPOINT_URL=...
AZURE_ML_API_KEY=...
```

## Ejecución
```bash
python main.py
```

Edita las herramientas en `tools/` para conectar con tu hardware/servicios reales.
